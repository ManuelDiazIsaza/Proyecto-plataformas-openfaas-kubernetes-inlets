# Presentación

En este directorio se encuentran los archivos que permiten generar una presentación que acompaña lo discutido en el texto.

Para obtener un PDF, ejecutar:

```
make pdf
```

Para obtener la presentación en HTML, ejecutar:

```
make 
```
