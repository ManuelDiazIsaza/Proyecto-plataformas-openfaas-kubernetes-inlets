En esta versi�n de la apliacaci�n en Flask, esta se comunica con el servidor de Redis.
Imagen que contiene la nueva versi�n es josanabr/demoflask-armv7:1.0.1.
