# README.md

En este directorio encontrará:

* [Pod](pod) un ejemplo donde se muestra como se corre un *pod* el cual ejecuta el servidor web `nginx`.

* [Ingress](ingress) ejemplo en desarrollo acerca de como usar el objeto *Ingress*

* [OpenFaaS](openfaas) directorio con ejemplos del uso de la plataforma de OpenFaaS
