# YAML

En este directorio se encuentran archivos YAML usados en el documento.

* [Flask + Redis](flaskredisapp) en este directorio se encuentra el archivo YAML que permite desplegar la aplicación descrita en [Get started with Docker Compose](https://docs.docker.com/compose/gettingstarted/) contra un cluster de Kubernetes con la herramienta `kubectl`.
