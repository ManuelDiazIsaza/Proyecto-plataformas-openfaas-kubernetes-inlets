# Libro sobre FaaS, OpenFaaS, Kubernetes, Kubernetes + OpenFaaS

Este libro se compila con la herramienta [pandoc](https://pandoc.org/installing.html) y [LaTeX](https://www.latex-project.org/get/).
Entonces para compilarlo:

* Instale `pandoc`
* Instale `latex`
* Instale `make`

Ejecute el comando:

```
make clean && make
```

Si no aparecen errores entonces en el directorio `output` encontrará el PDF del libro.
