#!/usr/bin/env bash
docker run --rm -d -p 5000:5000 josanabr/gtd-flask-app
