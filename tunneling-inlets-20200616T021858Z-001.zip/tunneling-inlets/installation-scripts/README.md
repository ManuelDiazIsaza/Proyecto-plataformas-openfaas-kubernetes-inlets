# README.md

Este directorio contiene los scripts que se invocan en el [Vagrantfile](../Vagrantfile) a la hora de aprovisionar la máquina virtual para esta práctica.

* [install-asciinema.sh](install-asciinema.sh)
* [install-docker.sh](install-docker.sh)
* [install-gcloud.sh](install-gcloud.sh)

