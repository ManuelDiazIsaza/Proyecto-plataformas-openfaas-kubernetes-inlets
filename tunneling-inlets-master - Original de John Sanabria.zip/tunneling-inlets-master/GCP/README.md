# README.md

Derivado del documento en este [enlace](https://pretired.dazwilkin.com/posts/200122/) se desarrollaron los siguientes scripts:

* `crear-inlets-exit-node.sh` este script permite crear un *Exit Node* en la plataforma GCP.

* `correr-cliente-inlets.sh` este script permite conectar la aplicación local con el *Exit Node* desplegado en GCP.

